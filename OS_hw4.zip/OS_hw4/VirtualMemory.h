//
//  VirtualMemory.h
//  OS_hw4
//
//  Created by Shangqi Wu on 15/2/27.
//  Copyright (c) 2015 Shangqi Wu. All rights reserved.
//

#ifndef __OS_hw4__VirtualMemory__
#define __OS_hw4__VirtualMemory__

#include <iostream>
#include <fstream>
#include <utility>
#include <vector>
#include <list>

using namespace std;

/*
 * This is header file of class VirtualMemory.
 * In this header file, a struct called Frame is defined.
 * Also, a skeleton of VirtualMemory class is defined.
 */

/* Struct Frame contains number of cells as bytes in physical frame, boolean variant dirty denotes if there are dirty bits have been written back. */
struct Frame {
	vector<signed char> cell;
	bool dirty;
};

class VirtualMemory {
private:
	/* 3 basic parameters for size. */
	unsigned int VirtualMemorySize;
	unsigned int PhysicalMemorySize;
	unsigned int PageSize;
	
	/* Derivative parameters. */
	unsigned int NumberOfPhysicalFrame;
	unsigned int NumberOfLogicalPage;
	
	/* Derivative parameters which are convenient for bit operations. */
	unsigned int PageNoLength;
	unsigned int LogicalPageNoLength;
	unsigned int PageOffsetLength;
	
	/* Masks for bit operations. */
	unsigned int OffsetMask;
	unsigned int PhysicalPageMask;
	unsigned int VirtualPageMask;
	
	/* Counters for relative events. */
	unsigned int SaveBackTime;
	unsigned int TLBhitTime;
	unsigned int PageFaultTime;
	unsigned int TotalAccessTime;
	
	/* Page table, uses logical page number as index, first element is corresponding physical frame number, second element indicates if the physical frame is valid for use. */
	vector<pair<unsigned int, bool> > PageTable;
	
	/* Each struct Frame stands for a physical frame. */
	vector<Frame> PageContent;
	
	/* There are 16 entires FIXED in TLB, fully-associated, first element is logical page number, second element is correspending physical frame number, using LRU replacement strategy. */
	list<pair<unsigned int, unsigned int> > TLB;
	
	/* Keep track of available physical frames. */
	list<unsigned int> AvailableFrameList;
	
	/* Keep track of used frames, or all valid page table entries, used for LRU page replacement. */
	list<unsigned int> UsedFrameList;
	
	/* This bin file is used as swap space. */
	fstream BINFile;
	
	/* Private methods. */
	
	/* Go through the TLB list to find matched page translation. */
	bool TLBlookaside(unsigned int &_log_page, unsigned int &_phy_page);
	/* After each page table access, use LRU to replace the most recent used page translation information. */
	bool TLBUpdate(pair<unsigned int, unsigned int> _new_TLB);
	/* Update used-frame-list, using LRU algorithm. */
	bool UsedFrameUpdate(unsigned int &_log_page_no);
	/* Load desired logical page content into physical frame. */
	bool load(unsigned int &_log_page_no);
	/* Save LRU physical frame back to swap space, when memory needs a replacement or the class deconstructs. */
	bool save(unsigned int &_log_page_no);
	/* A method calls save() depends on the situation first, then calls load(), to complete replacement. */
	bool swap(unsigned int &_log_page_no);
public:
	/* Public methods. */
	
	/* Constructor with default value. */
	VirtualMemory(unsigned int _VirtualMemorySize = 65536, unsigned int _PhysicalMemorySize = 65536, unsigned int _NumberOfPhysicalFrame = 256, string BINaddress = "./BACKING_STORE.bin");
	/* Method to handle read indication, or default indication. */
	bool Read(unsigned int &_log_addr);
	/* Method to handle write indication, processing dirty bits. */
	bool Write(unsigned int &_log_addr);
	/* Deconstructor closes bin file and save back dirty bits. */
	~VirtualMemory();
};

#endif /* defined(__OS_hw4__VirtualMemory__) */
