//
//  main.cpp
//  OS_hw4
//
//  Created by Shangqi Wu on 15/2/27.
//  Copyright (c) 2015 Shangqi Wu. All rights reserved.
//

#include <memory.h>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <limits>
#include "VirtualMemory.h"

using namespace std;

/*
 * This is main function of virtual memory manager, homework 4 of CS 543.
 * It has implemented original functionality of the project on the textbook, modification part of the project, and the additional functionality. 
 * Please use files provided in the zip file. 
 * To run this program, please type "OS_hw4 ./address.txt" in command-line.
 * Default parameters are: virtual memory size: 65536 bytes, physical memory size: 65536 bytes, number of frame: 256, address of bin file: ./BACKING_STORE.bin
 * Recommended parameters for testing modification part on the textbook are: virtual memory size: 65536 bytes, physical memory size: 32768 bytes, number of frame: 128, address of bin file: ./BACKING_STORE.bin
 * To test additional functionality, you can use following parameters: virtual memory size: 65536 bytes, physical memory size: 32768 bytes, number of frame: 128, address of bin file: ./BACKING_STORE.bin, please not that you are supposed to use the file "./address2.txt".
 */

int main(int argc, const char * argv[]) {
	/* In this program, there should be only 2 parameters in the command-line. Otherwise parameters cannot be correct, thus this program will terminate. */
	if (argc == 2) {
		/* Buffer to store test file, address.txt or address2.txt, content. */
		string input_line;
		/* Variants to store virtual memory initialization parameters. */
		unsigned int virtual_size;
		unsigned int physical_size;
		unsigned int frame_no;
		string bin_file;
		/* Let user choose to execute for different testing modes. */
		while (true) {
			int choice = -1;
			cout<<"Please enter your choice:\nPress 1 for default set of the project on the book\nPress 2 for modification part (128 frames) of the project on the book\nPress 3 for additional functionality(Read and Write)\nPress 4 to specify any parameters you want"<<endl;
			cin>>choice;
			/* Mode 1, 2, 3 are 3 set of pre-set parameters that for convenience of tester. */
			if (choice == 1) {
				virtual_size = 65536;
				physical_size = 65536;
				frame_no = 256;
				bin_file = "./BACKING_STORE.bin";
				break;
			/* Parameters for modification part on the book. */
			} else if (choice == 2) {
				virtual_size = 65536;
				physical_size = 32768;
				frame_no = 128;
				bin_file = "./BACKING_STORE.bin";
				break;
			/* Parameters for additional functionality, using with "address2.txt". */
			} else if (choice == 3) {
				virtual_size = 65536;
				physical_size = 32768;
				frame_no = 128;
				bin_file = "./BACKING_STORE.bin";
				break;
			} else if (choice == 4) {
				/* Read virtual memory size from user input. */
				while (true) {
					cout<<"Please enter size of virtual memory in bytes:"<<endl;
					cin>>virtual_size;
					if (!cin.fail()) {
						/* If the value is not a power of 2, require user the input a correct value. */
						if (log2(virtual_size) == (int)log2(virtual_size)) {
							break;
						}
					}
					/* Reset in stream, prepare to get correct input. */
					cin.clear();
					cin.ignore(numeric_limits<std::streamsize>::max(), '\n');
					cout<<"Your input does not meet parameter requirement. Please note that virtual memory size should be power of 2."<<endl;
				}
				/* Read physical memory size from user input. */
				while (true) {
					cout<<"Please enter size of physical memory in bytes:"<<endl;
					cin>>physical_size;
					if (!cin.fail()) {
						if (log2(physical_size) == (int)log2(physical_size)) {
							break;
						}
					}
					cin.clear();
					cin.ignore(numeric_limits<std::streamsize>::max(), '\n');
					cout<<"Your input does not meet parameter requirement. Please note that physical memory size should be power of 2."<<endl;
				}
				/* Read number of physical frames from user input. */
				while (true) {
					cout<<"Please enter number of frames that the physical memory has."<<endl;
					cin>>frame_no;
					if (!cin.fail()) {
						/* Number of frames should also be power of 2. */
						if (log2(frame_no) == (int)log2(frame_no)) {
							break;
						}
					}
					cin.clear();
					cin.ignore(numeric_limits<std::streamsize>::max(), '\n');
					cout<<"Your input does not meet parameter requirement. Please note that physical memory size should be power of 2."<<endl;
				}
				/* Get address of bin file from user input. */
				cout<<"Please enter bin file address as swap space."<<endl;
				cin>>bin_file;
				break;
			}
			cin.clear();
			cin.ignore(numeric_limits<std::streamsize>::max(), '\n');
			cout<<"Please just enter 1, 2, 3, or 4, nothing else."<<endl;
		}
		VirtualMemory VM(virtual_size, physical_size, frame_no, bin_file);
		input_line.clear();
		/* char * to read each line in test file. Each line in address.txt, address2.txt, is not supposed to be larger than 7 characters. */
		char line[20];
		ifstream TestFile(argv[1]);
		if (TestFile.is_open()) {
			while (TestFile) {
				/* Read address.txt line by line. */
				TestFile.getline(line, 20);
				if (*line != '\0') {
					input_line.append(line);
					unsigned int log_addr = (unsigned int)atoi(input_line.c_str());
					/* Remove redundant new line character '\r', if applicable. */
					if (input_line.at(input_line.size()-1) == '\r') {
						input_line.erase(--input_line.end());
					}
					/* If ends with "W", which indicates writing, calls write method. */
					if (input_line.at(input_line.size()-1) == 'W') {
						if (!VM.Write(log_addr)) {
							cerr<<"Address process encounters error."<<endl;
							break;
						}
					/* Else, if ends with "R" or integers, call read method. */
					} else {
						if (!VM.Read(log_addr)) {
							cerr<<"Address process encounters error."<<endl;
							break;
						}
					}
					input_line.clear();
				}
				/* Reset line before next iteration. */
				memset(line, 0, 20);
			}
		/* If the test file has error, exit program and return 2. */
		} else {
			cerr<<"Please check if the file path is correct."<<endl;
			return 2;
		}
		TestFile.close();
		return 0;
	/* If the number of parameters is not correct, the program will exit. */
	} else {
		cerr<<"You have to enter one and only one directory for test file."<<endl;
		return 1;
	}
}
