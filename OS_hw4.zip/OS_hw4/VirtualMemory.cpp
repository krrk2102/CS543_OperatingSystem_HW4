//
//  VirtualMemory.cpp
//  OS_hw4
//
//  Created by Shangqi Wu on 15/2/27.
//  Copyright (c) 2015 Shangqi Wu. All rights reserved.
//

#include <cstdlib>
#include <iomanip>
#include <cmath>
#include <limits>
#include "VirtualMemory.h"

using namespace std;

/*
 * This is cpp file for class VirtualMemory.
 * All methods mentioned in header file, the skeleton, have been implemented here.
 */

/* Constructor of VirtualMemory. */
VirtualMemory::VirtualMemory(unsigned int _VirtualMemorySize, unsigned int _PhysicalMemorySize, unsigned int _NumberOfPhysicalFrame, string BINaddress) {
	/* 3 essential parameters from initial value from input. */
	VirtualMemorySize = _VirtualMemorySize;
	PhysicalMemorySize = _PhysicalMemorySize;
	NumberOfPhysicalFrame = _NumberOfPhysicalFrame;
	/* Size of 1 page, or physical frame, in bytes. */
	PageSize = PhysicalMemorySize / _NumberOfPhysicalFrame;
	/* Calculating how many pages there are in virtual memory. */
	NumberOfLogicalPage = VirtualMemorySize / PageSize;
	
	/* Number of bits those parameters take, for convenience of bit-operations. */
	PageOffsetLength = log2(PageSize);
	LogicalPageNoLength = log2(NumberOfLogicalPage);
	PageNoLength = log2(NumberOfPhysicalFrame);
	
	/* Generating masks for bit-operations. */
	OffsetMask = PageSize - 1;
	PhysicalPageMask = NumberOfPhysicalFrame - 1;
	VirtualPageMask = NumberOfLogicalPage - 1;
	
	/* Initializing counter values. */
	SaveBackTime = 0;
	TLBhitTime = 0;
	TotalAccessTime = 0;
	PageFaultTime = 0;
	
	/* Initializing page table, of which size should be number of logical pages. */
	PageTable.resize(NumberOfLogicalPage);
	/* Mark every entry in the table as invalid initially. */
	for (unsigned int i = 0; i < NumberOfLogicalPage; i++) {
		PageTable[i].second = false;
	}
	
	/* Initializing content in physical frame, of which size should be number of physical frames. */
	PageContent.resize(NumberOfPhysicalFrame);
	/* Each frame has the number of bytes the same as page size, initially marked as not dirty. */
	for (unsigned int i = 0; i < NumberOfPhysicalFrame; i++) {
		PageContent[i].cell.resize(PageSize);
		PageContent[i].dirty = false;
	}
	
	/* All frames are available initially. */
	AvailableFrameList.resize(NumberOfPhysicalFrame);
	list<unsigned int>::iterator it = AvailableFrameList.begin();
	for (unsigned int i = 0; i < NumberOfPhysicalFrame; i++) {
		*it = i;
		++it;
	}
	
	/* Used frame list and TLB should be empty. */
	UsedFrameList.clear();
	TLB.clear();
	
	/* Open bin file, if there is something wrong with the file, terminate the program. */
	BINFile.open(BINaddress.c_str(), fstream::binary | fstream::out | fstream::in);
	if (!BINFile.is_open()) {
		cerr<<"Cannot open bin file."<<endl;
		abort();
	}
}

/* The method to handle read indication, or implicit(default) indication. */
bool VirtualMemory::Read(unsigned int &_log_addr) {
	/* Calculating logical page number and page offset by parsing logical address. */
	unsigned int LogicalPage = (_log_addr >> PageOffsetLength) & VirtualPageMask;
	unsigned int Page_Offset = _log_addr & OffsetMask;
	/* Initializing parameters to be calculated. */
	unsigned int PhysicalPage = 0;
	unsigned int PhysicalAddress = 0;
	/* Traverse TLB first */
	if (!TLBlookaside(LogicalPage, PhysicalPage)) {
		/* If the page is not in TLB, inquire page table then. */
		if (LogicalPage < NumberOfLogicalPage && UsedFrameList.size() <= NumberOfPhysicalFrame && Page_Offset < PageSize) {
			/* If the entry is invalid, it is a page fault and logical page need to be loaded or swapped. */
			if (!PageTable[LogicalPage].second) {
				PageFaultTime++;
				if (UsedFrameList.size() < NumberOfPhysicalFrame && AvailableFrameList.size() > 0) {
					/* In this case, there are still available frames in physical memory, no need to replace LRU frame. */
					PageTable[LogicalPage].first = AvailableFrameList.front();
					AvailableFrameList.pop_front();
					if (!load(LogicalPage)) {
						cerr<<"First time loading error while reading, logcal page number: "<<LogicalPage<<", logical address: "<<_log_addr<<endl;
						return false;
					}
				} else {
					/* In this case, all frames are occupied, replace LRU frame with the desired content. */
					if (!swap(LogicalPage)) {
						return false;
					}
				}
			}
			/* Assign correct value to variants. */
			PhysicalPage = PageTable[LogicalPage].first;
			PhysicalAddress = (PhysicalPage << PageOffsetLength) + Page_Offset;
		} else return false;
	} else {
		/* If in the TLB, last method has updated corresponding physical frame number to the variant PhysicalPage. */
		PhysicalAddress = (PhysicalPage << PageOffsetLength) + Page_Offset;
	}
	/* Displays information. */
	cout<<"[Read]  Virtual address: "<<setw(5)<<_log_addr<<" Physical address: "<<setw(5)<<PhysicalAddress<<" Value: "<<setw(4)<<(int)PageContent[PhysicalPage].cell[Page_Offset]<<endl;
	/* Update TLB information. */
	if (!TLBUpdate(make_pair(LogicalPage, PhysicalPage))) {
		cerr<<"TLB update error while reading. Virtual page number: "<<LogicalPage<<" Physical page number: "<<PhysicalPage<<endl;
		return false;
	}
	/* Update used frame list information. */
	if (!UsedFrameUpdate(LogicalPage)) {
		cerr<<"Page Table LRU tracker update error while writing. Virtual page number:"<<LogicalPage<<" Physical page number: "<<PhysicalPage<<endl;
		return false;
	}
	return true;
}

/* Method to handle write indication specifically. */
bool VirtualMemory::Write(unsigned int &_log_addr){
	/* Calculating and initializing address information. */
	unsigned int LogicalPage = (_log_addr >> PageOffsetLength) & VirtualPageMask;
	unsigned int Page_Offset = _log_addr & OffsetMask;
	unsigned int PhysicalPage = 0;
	unsigned int PhysicalAddress = 0;
	/* The same procedure as Read method, for traversing TLB and inquiring page table. */
	if (!TLBlookaside(LogicalPage, PhysicalPage)) {
		if (LogicalPage < NumberOfLogicalPage && UsedFrameList.size() <= NumberOfPhysicalFrame && Page_Offset < PageSize) {
			/* If page table entry is invalid, it encounters a page fault. */
			if (!PageTable[LogicalPage].second) {
				PageFaultTime++;
				if (UsedFrameList.size() < NumberOfPhysicalFrame && AvailableFrameList.size() > 0) {
					/* First-time load. */
					PageTable[LogicalPage].first = AvailableFrameList.front();
					AvailableFrameList.pop_front();
					if (!load(LogicalPage)) {
						cerr<<"First time loading error while writing, logcal page number: "<<LogicalPage<<", logical address: "<<_log_addr<<endl;
						return false;
					}
				} else {
					/* All frames used, swap LRU frame. */
					if (!swap(LogicalPage)) {
						return false;
					}
				}
			}
			PhysicalPage = PageTable[LogicalPage].first;
			PhysicalAddress = (PhysicalPage << PageOffsetLength) + Page_Offset;
			/* This is for write method, mark accessed physical frame as dirty. */
			PageContent[PhysicalPage].dirty = true;
		} else return false;
	} else {
		/* If in the TLB, get physical frame number directly, and mark frame as dirty. */
		PhysicalAddress = (PhysicalPage << PageOffsetLength) + Page_Offset;
		PageContent[PhysicalPage].dirty = true;
	}
	/* Display information. */
	cout<<"[Write] Virtual address: "<<setw(5)<<_log_addr<<" Physical address: "<<setw(5)<<PhysicalAddress<<" Value: "<<setw(4)<<(int)PageContent[PhysicalPage].cell[Page_Offset]<<endl;
	/* Update TLB. */
	if (!TLBUpdate(make_pair(LogicalPage, PhysicalPage))) {
		cerr<<"TLB update error while writing. Virtual page number: "<<LogicalPage<<" Physical page number: "<<PhysicalPage<<endl;
		return false;
	}
	/* Update used frame list. */
	if (!UsedFrameUpdate(LogicalPage)) {
		cerr<<"Page Table LRU tracker update error while writing. Virtual page number:"<<LogicalPage<<" Physical page number: "<<PhysicalPage<<endl;
		return false;
	}
	return true;
}

/* The method to save LRU frame content to swap space and load desired data into the frame. */
bool VirtualMemory::swap(unsigned int &_log_page_no) {
	/* Reflecting the LRU frame to desired entry in page table. */
	PageTable[_log_page_no].first = PageTable[UsedFrameList.back()].first;
	if (PageContent[PageTable[UsedFrameList.back()].first].dirty) {
		/* If there are dirty bits in LRU frame, save the entire frame back to swap space. Otherwise this step is skipped. */
		cout<<"Physical Frame, number: "<<PageTable[UsedFrameList.back()].first<<", is the least recent used and is preparing to be saved back, corresponding logical page number: "<<_log_page_no<<endl;
		if (!save(UsedFrameList.back())) {
			cerr<<"Swap saving back error, logical page number: "<<_log_page_no<<endl;
			return false;
		}
		/* If there are no dirty bits, simply mark corresponding page table entry as invalid. */
	} else PageTable[UsedFrameList.back()].second = false;
	/* Load desired logical page content into physical frame. */
	if (!load(_log_page_no)) {
		cerr<<"Swap loading error, logical page number: "<<_log_page_no<<endl;
		return false;
	}
	return true;
}

/* The method to load desired logical page content to corresponding frame. */
bool VirtualMemory::load(unsigned int &_log_page_no) {
	/* In order to load data into frame, the page table entry should be invalid initially. Also there should be no dirty bits in the frame. */
	if (!PageTable[_log_page_no].second && !PageContent[PageTable[_log_page_no].first].dirty) {
		/* This is variant that carries data by a byte. */
		char byte;
		/* Set file reading position at the beginning of desired logical page. */
		BINFile.seekg(_log_page_no<<PageOffsetLength);
		/* Write value to physical frame by one byte each time. */
		for (unsigned int i = 0; i < PageSize; i++) {
			BINFile.get(byte);
			PageContent[PageTable[_log_page_no].first].cell[i] = byte;
		}
		/* Mark the table entry as valid. */
		PageTable[_log_page_no].second = true;
		/* Mark the recent loaded frame cannot have dirty bits. */
		PageContent[PageTable[_log_page_no].first].dirty = false;
		return true;
	} else return false;
}

/* The method to save entire frame back. */
bool VirtualMemory::save(unsigned int &_log_page_no) {
	/* Inorder to save data back, the page table entry should be valid initially. */
	if (PageTable[_log_page_no].second && PageContent[PageTable[_log_page_no].first].dirty) {
		SaveBackTime++;
		/* Set file writing position at the beginning of the logical page to be swapped. */
		BINFile.seekp(_log_page_no<<PageOffsetLength);
		/* Save back data by one byte at one time. */
		for (unsigned int i = 0; i < PageSize; i++) {
			BINFile.put((char)PageContent[PageTable[_log_page_no].first].cell[i]);
		}
		/* Mark the table entry invalid. */
		PageTable[_log_page_no].second = false;
		/* Dirty bits are saved back. */
		PageContent[PageTable[_log_page_no].first].dirty = false;
		return true;
	} else return false;
}

/* The method traversing TLB. */
bool VirtualMemory::TLBlookaside(unsigned int &_log_page, unsigned int &_phy_page) {
	TotalAccessTime++;
	/* If the desired logical page number is in TLB, assignment corresponding physical frame number to input variant. */
	for (list<pair<unsigned int, unsigned int> >::iterator it = TLB.begin(); it != TLB.end(); ++it) {
		if (it->first == _log_page) {
			_phy_page = it->second;
			TLBhitTime++;
			return true;
		}
	}
	/* If it is not present in TLB, return false and input variant is not changed. */
	return false;
}

/* Update TLB information, using LRU algorithm. */
bool VirtualMemory::TLBUpdate(pair<unsigned int, unsigned int> _new_TLB) {
	if (TLB.size() < 16) {
		/* If TLB has less than 16 elements, simply add newly accessed page number pair to the front. */
		for (list<pair<unsigned int, unsigned int> >::iterator it = TLB.begin(); it != TLB.end(); ++it) {
			/* It should only compare the first value, in case the page has been assigned to other frame number after a few steps. */
			if (_new_TLB.first == it->first) {
				TLB.push_front(_new_TLB);
				it = TLB.erase(it);
				return true;
			}
		}
		TLB.push_front(_new_TLB);
		return true;
	} else if (TLB.size() == 16) {
		/* If TLB already has 16 elements, add newly accessed page numbers to the front and then delete the pair at the end. */
		for (list<pair<unsigned int, unsigned int> >::iterator it = TLB.begin(); it != TLB.end(); ++it) {
			if (_new_TLB.first == it->first) {
				TLB.push_front(_new_TLB);
				it = TLB.erase(it);
				return true;
			}
		}
		TLB.push_front(_new_TLB);
		TLB.pop_back();
		return true;
	} else {
		/* Though unlikely to happen, show this in code. */
		cerr<<"TLB size error."<<endl;
		return false;
	}
}

/* Update used frame list, it keeps all valid entries in page table. */
bool VirtualMemory::UsedFrameUpdate(unsigned int &_log_page_no) {
	/* If there are still available frames in the memory, simply add page number in the front. */
	if (UsedFrameList.size() < NumberOfPhysicalFrame) {
		/* If the entry appears in the list, pull entry number out of list and add it in the front. */
		for (list<unsigned int>::iterator it = UsedFrameList.begin(); it != UsedFrameList.end(); ++it) {
			if (*it == _log_page_no) {
				UsedFrameList.push_front(_log_page_no);
				it = UsedFrameList.erase(it);
				return true;
			}
		}
		/* Adding page table entry number in the front. */
		UsedFrameList.push_front(_log_page_no);
		return true;
		/* If all frames are occupied, add new entry in the list and remove the LRU entry in the list. */
	} else if (UsedFrameList.size() == NumberOfPhysicalFrame) {
		/* If the entry appears in the list, pull entry number out of list and add it in the front. */
		for (list<unsigned int>::iterator it = UsedFrameList.begin(); it != UsedFrameList.end(); ++it) {
			if (*it == _log_page_no) {
				UsedFrameList.push_front(_log_page_no);
				it = UsedFrameList.erase(it);
				return true;
			}
		}
		/* If this is a new entry, add it in the front and then delete the entry in the back. */
		UsedFrameList.push_front(_log_page_no);
		UsedFrameList.pop_back();
		return true;
	} else {
		cerr<<"Page Table size restriction."<<endl;
		return false;
	}
}

/* Destructor of this class. */
VirtualMemory::~VirtualMemory() {
	/* If there are frames contains dirty bits, save frames back. */
	for (unsigned int i = 0; i < NumberOfLogicalPage; i++) {
		if (PageTable[i].second && PageContent[PageTable[i].first].dirty) {
			if (!save(i)) {
				cerr<<"Frame contains dirty bits save back error, logical page number: "<<i<<", physical frame number: "<<PageTable[i].first<<endl;
			} else {
				cout<<"Logical page number: "<<i<<", whose corresponding physical frame number is: "<<PageTable[i].first<<", contains dirty bits has been saved back."<<endl;
			}
		}
	}
	/* Display counter values and statistics. */
	cout<<"Number of Translated Addresses = "<<TotalAccessTime<<endl;
	cout<<"Number of TLB hits is: "<<TLBhitTime<<endl;
	cout<<"TLB hit rate: "<<((double)TLBhitTime/(double)TotalAccessTime)*100<<"%"<<endl;
	cout<<"Number of page faults is: "<<PageFaultTime<<endl;
	cout<<"Page fault rate: "<<((double)PageFaultTime/(double)TotalAccessTime)*100<<"%"<<endl;
	cout<<"Number of save back operations is: "<<SaveBackTime<<endl;
	cout<<"Save back rate: "<<((double)SaveBackTime/(double)TotalAccessTime)*100<<"%"<<endl;
	/* Close bin file. */
	BINFile.close();
}